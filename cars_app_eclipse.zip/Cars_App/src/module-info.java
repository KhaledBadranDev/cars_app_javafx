module gp2_vorlageFX {
	exports gui;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
}